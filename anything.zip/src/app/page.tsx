import Hero from "@/components/hero";


export default function Home() {
  return (
    <section id="Whole-portfolio">
     <Hero />
    </section>
 );
}
