
import BlogPageSlider from "@/components/BlogPageSlider";
import BlogSlider from "@/components/BlogContentSlider1";
import BlogSlider2 from "@/components/BlogContentSlider2";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { BlogCategoriesdrop } from "@/components/BlogCategoriesdrop";
import BlogSlider3 from "@/components/BlogContentSlider3";

const images = [
  "/Writer-blog-pic-1.avif",
  "/Writer-blog-pic-2.avif",
  "/Writer-blog-pic-3.avif",
  "/Writer-blog-pic-4.avif",
  "/Writer-blog-pic-5.jpg",
  "/Writer-blog-pic-6.avif",
  "/Writer-blog-pic-7.avif",
  "/Writer-blog-pic-8.avif",
  "/Writer-blog-pic-9.avif",
  "/Writer-blog-pic-10.avif",
  "/Writer-blog-pic-11.jpg",
  "/Writer-blog-pic-12.avif",
];

const Blogs: React.FC = () => {
  

  return (
   <section>
        <section className=" mt-[1rem] mb-[2rem] h-screen">
        <br />
        <div>
        <BlogPageSlider />
        </div>
         <br />
        <br />
        </section>
        <br />
        <br />
    
     <div>
     <div className="m-auto text-center z-50">
       <div className="pt-[8rem]">
       <h4 className="text-[20px] pb-[10px]">Writers-Blogs</h4>
       <hr className="md:w-[1140px] w-[400px] text-center m-auto" />
       </div>
        <div className="p-[2rem] mb-[2rem]">
          <div>
          <BlogSlider />
          </div>
          <br />
       </div>
     </div>
          <div className="m-auto text-center z-50">
       <div className="pt-[8rem]">
       <h4 className="text-[20px] pb-[10px]">Gamers-Blogs</h4>
       <hr className="md:w-[1140px] w-[400px] text-center m-auto" />
        <div className="p-[2rem] mb-[2rem]">
          <div>
          <BlogSlider2 />
          </div>
       </div>
       </div>
      </div>
      <div className="m-auto text-center z-50">
       <div className="pt-[8rem]">
       <h4 className="text-[20px] pb-[10px]">Programing-Blogs</h4>
       <hr className="md:w-[1140px] w-[400px] text-center m-auto" />
       </div>
        <div className="p-[2rem] mb-[2rem]">
          <div>
          <BlogSlider3 />
          </div>
          <br />
       </div>
     </div>
          {/* <div className="grid grid-cols-3 grid-rows-4 gap-[2rem]">
            {BlogContainer.map((item) => (
              <div key={item.id} className="bg-white rounded-[10px] p-[20px] w-[384px] h-[405px]">
                <Image
                  src={item.image}
                  alt="my image"
                  height={205}
                  width={310}
                  className="rounded-[10px] pb-[2rem] m-auto"
                />
                <p className="text-black text-[12px] p-1 text-left">
                  Lorem ipsum dolor sit, amet consectetur adipisicing elit.{" "}
                  <br />
                  Dolorem ex repellendus ea maxime quas incidunt quo praesentium
                  excepturi <br />
                  illo similique. Quas voluptate quisquam, fugiat aut illo
                  officia sunt quasi minus!
                </p>
                
                
              </div>
            ))}
          </div> */}
        </div>
      </section>
  );
};
export default Blogs;


const BlogContainer = [
  {
    id: 5,
    image: "/Blog-image-5.jpg",
  },
  {
    id: 6,
    image: "/Blog-image-10.avif",
  },
  {
    id: 7,
    image: "/Blog-image-7.avif",
  },
  {
    id: 8,
    image: "/Blog-image-8.avif",
  },
  {
    id: 9,
    image: "/Blog-image-9.avif",
  },
];
