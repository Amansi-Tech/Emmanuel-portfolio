import React from 'react'
 interface User {
  id: number,
  name: string,
 }
const ViewsPage = async () => {
  const res = await fetch('https://jsonplaceholder.typicode.com/users')
  const users: User[] = await res.json();
  return (
    <div>
    <div className='mb-[3rem] mt-[1rem] text-[2rem] text-center'>ViewsPage</div> 
    <ul className='grid grid-cols-3 grid-row-2 gap-[10px] m-auto text-center'>
      <h3>Daily-views</h3>
      <h3>Weekly-views</h3>
      <h3>Monthly-views</h3>
    {users.map(user => <li key={user.id}>{user.name}</li>)}
    </ul>
    <ul>
      <p>Samuel john</p>
      <p></p>
    </ul>
    </div>
  
    
  )
}

export default ViewsPage