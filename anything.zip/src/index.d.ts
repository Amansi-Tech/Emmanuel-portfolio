import * as ReactScroll from "./modules/index";
export = ReactScroll;