import React from "react";
import { StarIcon } from "lucide-react";
import { Button } from "./ui/button";
import { Element } from "react-scroll";

const Abouthero = () => {
 
  return (
    <Element name="test1">
      <div>
        <div className="p-[25px] mt-[5rem] bg-blue-500 cursor-context-menu text-center">
          <div data-aos="fade-up" className="pt-24 ">
            <h2 className="text-[35px] mb-[13px] mt-[-10px]">About-us</h2>
            <div className="flex items-center justify-center gap-[2px] text-white mb-[10px]">
              <div className="flex gap-[10px] items-center justify-center">
                {reactfill.map((d) => (
                  <StarIcon fill="gold" strokeWidth="1" key={d.id} />
                ))}
              </div>
            </div>
            <p className="md:w-[800px] w-[370px] m-auto text-center">
              I'm creative designer ready for any perpective work i see each
              site as i build like a child <br />
              which i have to build-up to be great, presenting, useful and
              dynamicly-engeneered. Programing <br />
              is not for the weak so i have dedecated my time in being creative
              logical and thinking out-side the <br />
              box to make beautiful, dynamic, static, breathe-taking sites
            </p>
            <div className="flex items-center justify-center gap-[30px] mb-[8rem]">
              <Button className="bg-tranparent border-2 border-white text-white p-[12px] text-left mt-[35px] text-[14px] h-[30px] hover:bg-blue-500 hover:text-white">
                Read-more
              </Button>
              <Button className="bg-tranparent border-2 border-white text-white p-[12px] text-left mt-[35px] text-[14px] h-[30px] hover:bg-blue-500 hover:text-white">
                Learn-more
              </Button>
            </div>
          </div>
        </div>
      </div>
      </Element>
  );
};

export default Abouthero;
const reactfill = [
  {
    id: 1,
  },
  {
    id: 2,
  },
  {
    id: 3,
  },
  {
    id: 4,
  },
  {
    id: 5,
  },
];
