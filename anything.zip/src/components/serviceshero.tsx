import React from 'react'
import { Button } from "./ui/button";
import { Element } from "react-scroll";
 import {
    Building2,
    Figma,
    SquareDashedBottomCodeIcon,
  } from "lucide-react"; 
const Serviceshero = () => {

  return (
    <Element name="test2">
    <div> <div className="text-center p-[25px]">
    <div data-aos="fade-down" className="relative pt-24 pb-24">
      <h2 className="text-[35px] mb-[20px]">Services</h2>
      <div className=" md:grid md:grid-cols-3 md:grid-rows-1 mb-[85px] grid grid-cols-1 grid-rows-1 gap-[20px] md:ml-[27px] ml-[1px] justify-center">
        <div className="bg-transparent border-2 border-blue-500 w-[23rem] relative h-[17rem] text-white p-[20px] rounded-[10px]">
          <div className="mb-[10px] bg-white w-[35px] p-[5px] rounded-[20px]">
            <span className="  text-blue-500  text-center">
              <Building2 />
            </span>
          </div>
            <h3 className=" text-[21px] text-left">Building of sites/apps</h3>
          <p className="w-[300px] pt-[10px] text-[13px] text-left ">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab
            magni illum, eius iure dolore error illo minus quas impedit
            recusandae.
          </p>
          <Button className="bg-tranparent border-2 text-white p-[12px] text-left mt-[35px] ml-[-16rem] border-blue-500 text-[13px] h-[30px] hover:bg-blue-500 hover:text-white">
            Inquire
          </Button>
        </div>
        <div className="bg-transparent border-2 border-blue-500 w-[23rem] relative h-[17rem] text-white p-[20px] rounded-[10px]">
          <div className="mb-[10px] bg-white w-[35px] p-[5px] rounded-[20px]">
            <span className=" text-blue-500 text-center">
              <Figma />
            </span>
          </div>
            <h3 className=" text-[21px] text-left">Graphics-designer</h3>
          <p className="w-[300px] pt-[10px]  text-[13px] text-left ">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab
            magni illum, eius iure dolore error illo minus quas impedit
            recusandae.
          </p>
          <Button className="bg-tranparent border-2 text-white p-[12px] text-left mt-[35px] ml-[-16rem] border-blue-500 text-[13px] h-[30px] hover:bg-blue-500 hover:text-white">
            Inquire
          </Button>
        </div>
        <div className="bg-transparent border-2 border-blue-500 w-[23rem] relative h-[17rem] text-white p-[20px] rounded-[10px]">
          <div className="mb-[10px] bg-white w-[35px] p-[5px] rounded-[20px]">
            <span className=" text-blue-500 text-center">
              <SquareDashedBottomCodeIcon />
            </span>
          </div>
            <h3 className=" text-[21px] text-left">UI/UX-designer</h3>
          <p className="w-[300px] pt-[10px] text-[13px] text-left ">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab
            magni illum, eius iure dolore error illo minus quas impedit
            recusandae.
          </p>
          <Button className="bg-tranparent border-2 text-white p-[12px] text-left mt-[35px] ml-[-16rem] border-blue-500 text-[13px] h-[30px] hover:bg-blue-500 hover:text-white">
            Inquire
          </Button>
        </div>
      </div>
    </div>
  </div>
  </div>
  </Element>
  )
}

export default Serviceshero;