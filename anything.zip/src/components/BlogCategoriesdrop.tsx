"use client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuPortal,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Code2, Facebook, Gamepad, Mail, MenuIcon, PenIcon, Phone } from "lucide-react";
import { Link as ScrollLink } from "react-scroll";
export function BlogCategoriesdrop() {
    const handleSetActive = (to: string) => {
        console.log(to);
      };
  return (
    <DropdownMenu>
      <DropdownMenuTrigger>
        <div className="flex gap-[1px] items-center text-blue-500">
            <MenuIcon />
            Categories</div>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-44">
        <DropdownMenuLabel>Blog-contents</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem>
        <ScrollLink
                    activeClass="active"
                    to="blog1"
                    spy={true}
                    smooth={true}
                    offset={50}
                    duration={500}
                    onSetActive={handleSetActive}

                  >
         <PenIcon />
         <span>Writers-blog</span>
         </ScrollLink>
        </DropdownMenuItem>
        <DropdownMenuItem>
        <ScrollLink
                    activeClass="active"
                    to="blog2"
                    spy={true}
                    smooth={true}
                    offset={50}
                    duration={500}
                    onSetActive={handleSetActive}

                  >
          <Gamepad />
          <span>Gamers-blogs</span>
        </ScrollLink>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <Code2 />
          <span>Programers-blog</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
