import { Facebook, Github, Linkedin, Twitter } from "lucide-react";
import { Button } from "./ui/button";

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-10 mt-16 bottom-0 ">
      <div className="container mx-auto px-6 sm:px-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-[12px]">
          <div>
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-gray-400">About Me</a></li>
              <li><a href="https://github.com/Amansi-Tech" className="hover:text-gray-400">Projects</a></li>
              <li><a href="#" className="hover:text-gray-400">Blog</a></li>
              <li><a href="#" className="hover:text-gray-400">Contact</a></li>
            </ul>
          </div>
          <div className="md:m-0 m-auto">
            <h3 className="text-xl font-semibold mb-4 ">Follow Me</h3>
            <div className="flex space-x-6 ">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400">
                <Github className="h-6 w-6" />
              </a>
            </div>
          </div>

          <div className=" md:pb-0 pb-[2rem] md:text-justify text-right">
            <h3 className="text-xl font-semibold mb-4">Contact</h3>
            <ul className="space-y-2">
              <li><a href="mailto:youremail@example.com" className="hover:text-gray-400">p.star.chinedu@gmail.com</a></li>
              <li><a href="tel:+1234567890" className="hover:text-gray-400">+(234) 8023101101 </a></li>
              <li><p className="text-gray-400">Woji: Porthacourt, Nigeria</p></li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-4">Newsletter</h3>
            <p className="text-gray-400 mb-4">Sign up for my newsletter to get the latest updates on my projects, blog posts, and more.</p>
            <form action="#" method="POST" className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0">
              <input
                type="email"
                name="email"
                placeholder="Enter your email"
                className="px-4 py-2 w-[205px] rounded-md bg-gray-700 text-white placeholder-gray-400 focus:outline-none"
              />
              <Button
                className="mt-2 sm:mt-0 sm:ml-4 p-[10px] bg-blue-600 hover:bg-blue-500 text-white rounded-md transition"
              >
                Subscribe
              </Button>
            </form>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8 text-center">
          <p className="text-sm text-gray-400">
            &copy; {new Date().getFullYear()} Emmanuel/Amansi-codes. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}