import { LucideEye } from "lucide-react";
import Link from "next/link";
import React from "react";

const views = () => {
  return (
    <div className="ml-[1210px] mt-[580px] fixed shadow-gray-400 z-50">
      <Link href="/Views">
        <p className="text-white">20+</p>
        <div className="bg-white rounded-[100px] h-[34px] p-[6px] hover:bg-blue-500">
          <LucideEye className="text-black hover:text-white" />
        </div>
      </Link>
    </div>
  );
};

export default views;
