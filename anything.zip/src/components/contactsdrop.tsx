"use client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuPortal,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Facebook, Mail, Phone } from "lucide-react";
export function Contactdrop() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger>
        <div className="group">Contacts
        <div className="w-0 relative z-50 h-1 rounded-[7px] bg-blue-400 transition-all duration-1000 bottom-0 right-0 left-0 group-hover:w-full"></div>
        </div>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-44">
        <DropdownMenuLabel>contact-us</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem>
          <Phone />
          <span>08023101101</span>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <Mail />
          <span>p.star.chinedu@gmail.com</span>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <Facebook />
          <span>swizz bg</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
