"use client"
import React, { useState, useEffect } from 'react';
import { BlogCategoriesdrop } from './BlogCategoriesdrop';
const images = [
    "/Writer-blog-pics/Writer-blog-pic-1.avif",
    "/Writer-blog-pics/Writer-blog-pic-2.avif",
    "/Writer-blog-pics/Writer-blog-pic-3.avif",
    "/Writer-blog-pics/Writer-blog-pic-4.avif",
    "/Writer-blog-pics/Writer-blog-pic-5.avif",
    "/Writer-blog-pics/Blog-image-5.jpg",
    "/Writer-blog-pics/Writer-blog-pic-6.avif",
    "/Writer-blog-pics/Writer-blog-pic-7.avif",
    "/Writer-blog-pics/Blog-image-11.jpg",
    "/Random-blog-pics/Blog-image-1.avif",
    "/Random-blog-pics/Blog-image-2.avif",
    "/Random-blog-pics/Blog-image-3.avif",
    "/Random-blog-pics/Blog-image-4.avif",
    "/Random-blog-pics/Blog-image-5.avif",
    "/Random-blog-pics/Blog-image-6.avif",
    "/Random-blog-pics/Blog-image-7.avif",
    "/Random-blog-pics/Blog-image-8.avif",
    "/Random-blog-pics/Blog-image-9.avif",
    "/Random-blog-pics/Blog-image-10.avif",
    "/Random-blog-pics/Blog-image-12.avif",
  ];

const BlogPageSlider: React.FC = () =>{
    const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000); 

    return () => clearInterval(interval);
  }, []);

    return(
    <section className='h-screen'>
    <div className="absolute inset-0 transition-all duration-1000 ease-in-out mt-[55px]">
       <div>
       {images.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ${
              currentIndex === index ? 'opacity-100' : 'opacity-0'
            }`}
            style={{ backgroundImage: `url(${image})`,
                backgroundSize:"cover",
                backgroundPosition:"center"
            }}
          >
    <div>
      <div className="mt-[20px] ml-[1125px]">
      <BlogCategoriesdrop />
      </div>
    <div className="text-center m-auto pt-[5rem]">
    <h1 className="text-[60px] text-white ">Blogs-page</h1>
    <h2 className="text-[30px]">Discover Learn, Enhance, and Modify From My Blogs-page</h2>
    </div>
    </div>
          
          </div>
             ))}
       </div>
       </div>
    </section>
  
    
    );
}
export default BlogPageSlider;