"use client"
import React, { useState } from 'react';
import { Button } from './ui/button';
import { Element } from "react-scroll";
type Blog = {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
};

const blogs: Blog[] = [
  {
    id: 1,
    title: 'Programers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Programing-blog-pics/programing-blog-pic-1.avif',
  },
  {
    id: 2,
    title: 'Programers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Programing-blog-pics/programing-blog-pic-2.avif',
  },
  {
    id: 3,
    title: 'Programers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Programing-blog-pics/programing-blog-pic-3.avif',
  },
  {
    id: 4,
    title: 'Programers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Programing-blog-pics/programing-blog-pic-4.avif',
  },
  {
    id: 5,
    title: 'Programers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Programing-blog-pics/programing-blog-pic-5.jpg',
  },
  {
    id: 6,
    title: 'Programers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Programing-blog-pics/programing-blog-pic-6.avif',
  },
  {
    id: 7,
    title: 'Programers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Programing-blog-pics/programing-blog-pic-7.jpg',
  },
  {
    id: 8,
    title: 'Programers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Programing-blog-pics/programing-blog-pic-8.avif',
  },
];

const BlogSlider3: React.FC = () => {
  const [selectedBlog, setSelectedBlog] = useState<Blog | null>(null);

  const handleBlogClick = (blog: Blog) => {
    setSelectedBlog(blog);
  };

  return (
    
    <div className="p-4 h-screen">
      {/* Blog Slider Row */}
      <Element name="blog2">
      <div className="flex overflow-x-auto space-x-4">
        {blogs.map((blog) => (
          <div
            key={blog.id}
            className="min-w-[100px] mb-4 flex-shrink-0 bg-white text-black rounded-lg shadow p-4 cursor-pointer hover:bg-gray-200"
            onClick={() => handleBlogClick(blog)}
          >
            <img
              src={blog.imageUrl}
              alt={blog.title}
              className="w-full h-32 object-cover rounded-md"
            />
            <h3 className="mt-2 text-[12px] font-bold">Click to learn-more</h3>
          </div>
        ))}
      </div>

      {/* Selected Blog Details */}
      {selectedBlog && (
        <div className="mt-6 p-4 bg-gray-100 rounded-lg shadow md:flex md:gap-8">
          <img src={selectedBlog.imageUrl} alt="" 
          className="md:pb-0 pb-[20px]"
          />
         <div>
         <p className="mt-2 text-black">{selectedBlog.description}</p>
         <br />
         <Button className="w-[345px] h-[16px] text-white bg-blue-500 text-left p-[14px] hover:bg-blue-400">{selectedBlog.title}</Button>
         </div>
        </div>
      )}
    </Element>
    </div>
  );
};

export default BlogSlider3;