"use client"
import React, { useState } from 'react';
import { Button } from './ui/button';
import { Element } from "react-scroll";
type Blog = {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
};

const blogs: Blog[] = [
  {
    id: 1,
    title: 'Writers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus! incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Writer-blog-pics/Writer-blog-pic-1.avif',
  },
  {
    id: 2,
    title: 'Writers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime quas Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus! incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Writer-blog-pics/Writer-blog-pic-2.avif',
  },
  {
    id: 3,
    title: 'Writers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus! quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Writer-blog-pics/Writer-blog-pic-3.avif',
  },
  {
    id: 4,
    title: 'Writers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!  quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Writer-blog-pics/Writer-blog-pic-4.avif',
  },
  {
    id: 5,
    title: 'Writers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus! quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Writer-blog-pics/Writer-blog-pic-5.avif',
  },
  {
    id: 6,
    title: 'Writers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus! quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Writer-blog-pics/Writer-blog-pic-6.avif',
  },
  {
    id: 7,
    title: 'Writers-content',
    description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem ex repellendus ea maxime Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus! quas incidunt quo praesentiumexcepturi illo similique. Quas voluptate quisquam, fugiat aut illoofficia sunt quasi minus!',
    imageUrl: '/Writer-blog-pics/Writer-blog-pic-7.avif',
  },
];

const BlogSlider: React.FC = () => {
  const [selectedBlog, setSelectedBlog] = useState<Blog | null>(null);

  const handleBlogClick = (blog: Blog) => {
    setSelectedBlog(blog);
  };

  return (
    
    <div className="p-4 h-screen">
      {/* Blog Slider Row */}
      <Element name="blog1">
      <div className="flex overflow-x-auto space-x-4">
        {blogs.map((blog) => (
          <div
            key={blog.id}
            className="min-w-[100px] mb-4 flex-shrink-0 bg-white text-black rounded-lg shadow p-4 cursor-pointer hover:bg-gray-200"
            onClick={() => handleBlogClick(blog)}
          >
            <img
              src={blog.imageUrl}
              alt={blog.title}
              className="w-full h-32 object-cover rounded-md"
            />
            <h3 className="mt-2 text-[12px] font-bold">Click to learn-more</h3>
          </div>
        ))}
      </div>

      {/* Selected Blog Details */}
      {selectedBlog && (
        <div className="mt-6 p-4 bg-gray-100 rounded-lg shadow md:flex md:gap-[1rem]">
          <img src={selectedBlog.imageUrl} alt="" 
          className="md:pb-0 pb-[20px] rounded-[5px]"
          />
         <div>
          <h2 className="text-black text-[30px] text-left pb-[1rem]">{selectedBlog.title}</h2>
         <p className="mt-2 text-black text-left w-[530px]">{selectedBlog.description}</p>
         <br />
         <Button className="w-[500px] h-[16px] text-white bg-blue-500 text-center p-[14px] hover:bg-blue-400">Learn-more</Button>
         </div>
        </div>
      )}
      </Element>
    </div>
  );
};

export default BlogSlider;



 

