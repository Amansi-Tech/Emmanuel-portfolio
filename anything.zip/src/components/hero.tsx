"use client";
import React from "react";
import Image from "next/image";
import { useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import Skills from "./skills";
import Abouthero from "./abouthero";
import Serviceshero from "./serviceshero";
import ProgressBars from "./progress";

const Hero = () => {
  useEffect(() => {
    AOS.init({
      once: false,
      offset: 50,
      duration: 1000,
    });
  }, []);
  return (
    <section>
     <section className="h-screen"
     style={{ backgroundImage: `url(/portfolio-image-8.avif)`,
      backgroundSize:"cover",
      backgroundPosition:"center"
  }}
     
     >
     <div className=" md:flex md:pt-[8rem] pt-[7rem] pl-[25px] pb-[-5px] md:items-center md:gap-[17rem]">
        <div className=" md:mt[-5rem]" data-aos="fade-up">
          <div>
          <h2 className="text-[30px]">Welcome to</h2>
          <h1 className="text-[37px] md:text-[54px] font-bold">
            <span className="text-blue-500 font-bold">Emmanuel's</span>{" "}
            portfolio
          </h1>
          <p className="w-[300px]">
            This portfolio is showing of the works,
            <br />
            blogs, git-hub, services and about <br />
            Emmanuel the web-designer/web-engeneer
          </p>
          </div>
        </div>
        <div
          className="md:w-[360px] md:h-[350px] h-[290px] w-[300px] m-[30px] text-center bg-blue-500 md:p-[20px] rounded-[1050px] md:mt-[1rem] md:mr-[1px]"
          data-aos="fade-up"
        >
          <Image
            src="/next.js-pic5.avif"
            alt="my image"
            height={600}
            width={800}
            className="rounded-[1050px] md:h-[310px] md:w-[505px] h-[290px] md:p-0 w-[350px] p-[2rem] md:ml-0 "
          />
        </div>
      </div>
     </section>
      <Abouthero />
      <Serviceshero />
      <Skills />
      <br />
      <br />
       <div className=" text-center m-auto h-screen" data-aos="fade-down">
       <h3 className="text-[35px]">Progress level</h3>
       <br />
       <br />
        <div>
        <ProgressBars />
        </div>
       </div>
        {/* <div
          className="flex gap-[30px] items-center text-white justify-center mt-[4rem]"
          data-aos="fade-down"
        >
          <div className=" p-[10px] ">
            <h2 className="text-[50px] text-center">3+</h2>
            <hr className=" w-[10rem] text-white" />
            <p>YEARS OF EXPERINCES</p>
          </div>
          <div className=" p-[10px] ">
            <h2 className="text-[50px] text-center">16+</h2>
            <hr className=" w-[7rem] text-white" />
            <p>HAPPY CLIENTS</p>
          </div>
          <div className=" p-[10px]">
          

            <p>PROJECTS DONE</p>
          </div>
        </div> */}
    </section>
  );
};

export default Hero;
