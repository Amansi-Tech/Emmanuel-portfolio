"use client";
import { Button } from "./ui/button";
import { useEffect } from "react";
import AOS from "aos";
import { Contactdrop } from "./contactsdrop";
import Modals from "./modals";
import { Link as ScrollLink } from "react-scroll";
import "aos/dist/aos.css";
import React, { useState } from "react";
import Link from "next/link";

const Header: React.FC = () => {
  useEffect(() => {
    AOS.init({
      once: false,
      offset: 50,
      duration: 1000,
    });
  }, []);
  const handleSetActive = (to: string) => {
    console.log(to);
  };
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <section>
      <div className="">
        <div className="backdrop-blur-md bg-cover top-0 left-0 right-0 z-50 bg-white/60 fixed flex items-center md:gap-[130px] gap-[30px] p-3 md:w-[85rem] w-[50rem] h-[4rem]">
          <Link href="/">
            <h1 className=" text-white text-[25px] pl-[14px] rounded-1xl font-bold cursor-context-menu">
              Emma
            </h1>
          </Link>
          <div className="relative ">
            {/* Menu bar for smaller screens */}
            <div className="flex items-center justify-between md:hidden px-4 py-2 ml-auto text-white">
              <button onClick={toggleSidebar} className="text-2xl ml-[7rem]">
                ☰
              </button>
            </div>

            {/* Sidebar */}
            <div
              className={`fixed top-0 right-0 h-[45rem] w-[300px] bg-blue-600  text-white z-50 transform ${
                isSidebarOpen ? "translate-x-0" : "-translate-x-full"
              } transition-transform duration-300 md:hidden`}
            >
              <button
                onClick={toggleSidebar}
                className="absolute top-4 right-4 text-2xl"
              >
                ✕
              </button>
              <ul className="flex flex-col items-start gap-[4rem] mt-10 ml-4">
                <li className=" group text-white cursor-context-menu">
                  <ScrollLink
                    activeClass="active"
                    to="test1"
                    spy={true}
                    smooth={true}
                    offset={50}
                    duration={500}
                    onSetActive={handleSetActive}
                  >
                    About
                  </ScrollLink>

                  <div className="w-0 rounded-[7px] relative z-50 h-1 bg-blue-400 transition-all duration-1000 bottom-0 right-0 left-0 group-hover:w-full"></div>
                </li>
                <li className="group text-white cursor-context-menu">
                  <ScrollLink
                    activeClass="active"
                    to="test2"
                    spy={true}
                    smooth={true}
                    offset={50}
                    duration={500}
                    onSetActive={handleSetActive}
                  >
                    Services
                  </ScrollLink>
                  <div className="w-0 rounded-[7px] relative z-50 h-1 bg-blue-400 transition-all duration-1000 bottom-0 right-0 left-0 group-hover:w-full"></div>
                </li>
                <Contactdrop />
                <Link href="/Blogs">
                  <li className="group text-white cursor-context-menu">
                    Blogs
                    <div className="w-0 rounded-[7px] relative z-50 h-1 bg-blue-400 transition-all duration-1000 bottom-0 right-0 left-0 group-hover:w-full"></div>
                  </li>
                </Link>
                <div className=" flex items-center justify-center gap-[15px] md:ml-[160px]">
                  <Button className="bg-transparent border-2 border-white  text-white p-[8px] text-[13px] h-[30px] hover:bg-blue-400">
                    <a
                      href="https://github.com/Amansi-Tech"
                      className="text-white  hover:text-white"
                    >
                      View-Git
                    </a>
                  </Button>
                  <Button
                    className="bg-transparent border-2 border-white text-white p-[8px] text-[13px] h-[30px] hover:bg-blue-400"
                    onClick={openModal}
                  >
                    Get-in-touch
                  </Button>
                </div>
              </ul>
            </div>

            {/* Full navigation for larger screens */}
            <nav className="hidden md:flex items-center justify-between px-4 py-2">
              <ul className="flex items-center md:gap-[25px] gap-[10px] md:ml-[260px] justify-center">
                <li className=" group text-white cursor-context-menu">
                  <ScrollLink
                    activeClass="active"
                    to="test1"
                    spy={true}
                    smooth={true}
                    offset={50}
                    duration={500}
                    onSetActive={handleSetActive}
                  >
                    About
                  </ScrollLink>

                  <div className="w-0 rounded-[7px] relative z-50 h-1 bg-blue-400 transition-all duration-1000 bottom-0 right-0 left-0 group-hover:w-full"></div>
                </li>
                <li className="group text-white cursor-context-menu">
                  <ScrollLink
                    activeClass="active"
                    to="test2"
                    spy={true}
                    smooth={true}
                    offset={50}
                    duration={500}
                  >
                    Services
                  </ScrollLink>
                  <div className="w-0 rounded-[7px] relative z-50 h-1 bg-blue-400 transition-all duration-1000 bottom-0 right-0 left-0 group-hover:w-full"></div>
                </li>
                <Contactdrop />
                <li className="group text-white cursor-context-menu">
                  <Link href="/Blogs">
                    Blogs
                    <div className="w-0 rounded-[7px] relative z-50 h-1 bg-blue-400 transition-all duration-1000 bottom-0 right-0 left-0 group-hover:w-full"></div>
                  </Link>
                </li>
              </ul>
              <div className="flex items-center justify-center gap-[25px] md:ml-[267px]">
                <Button className="bg-transparent border-2 border-white  text-white p-[8px] text-[13px] h-[30px] hover:bg-blue-400">
                  <a
                    href="https://github.com/Amansi-Tech"
                    className="text-white  hover:text-white"
                  >
                    View-Git
                  </a>
                </Button>
                <Button
                  className="bg-transparent border-2 border-white text-white p-[8px] text-[13px] h-[30px] hover:bg-blue-400"
                  onClick={openModal}
                >
                  Get-in-touch
                </Button>
              </div>
            </nav>
          </div>
        </div>
      </div>

      <Modals isOpen={isModalOpen} onClose={closeModal} title="Welcome!">
        <div className="mt-[-2.5rem]">
          <div className="text-blue-500 text-center mb-[1rem]">
            <h2 className="font-bold text-[25px]">Contact form</h2>
            <p className="text-black">Get-in-touch</p>
          </div>
          <div className="grid grid-cols-1 grid-rows-4 gap-[7px] mt-[-1rem]">
            <div>
              <div>
                <label htmlFor="Name" className="text-black">
                  Your-name
                </label>
              </div>
              <input
                type="text"
                placeholder="Your-name"
                className=" border border-black w-[21rem] rounded-[2px] p-[5px] outline-blue-500"
              />
            </div>
            <div>
              <div>
                <label htmlFor="Email" className="text-black">
                  Email
                </label>
              </div>
              <input
                type="email"
                name=""
                id=""
                placeholder="Enter your email address"
                className=" border border-black w-[21rem] rounded-[2px] p-[5px] outline-blue-500"
              />
            </div>
            <div>
              <textarea
                name=""
                id=""
                placeholder="Your message"
                className=" border border-black w-[21rem] rounded-[2px] p-[5px]  outline-blue-500"
              ></textarea>
            </div>
            <div>
              <button
                type="submit"
                className="text-white bg-blue-500 p-[5px] w-[21rem]"
                onClick={closeModal}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </Modals>
    </section>
  );
};

export default Header;
