"use client";
import React, { useState, useEffect, useRef } from "react";

const ProgressBars: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.9 } 
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <div
      ref={sectionRef}
      className="md:m-auto m-[10px] text-center text-black bg-white px-4 md:w-[39rem] w-[25rem] h-[18rem] rounded-[10px]"
    >
        <br />
      {/* Progress Bar 1 */}
      <div>
        <h3>Level of happy-clients</h3>
        <br />
        <div className="md:w-[550px] w-[350px] max-w-xl bg-gray-300 rounded-full h-2">
          <div
            className={`bg-blue-500 h-2 rounded-full transition-all duration-1000 ease-in-out ${
              isVisible ? "md:w-[250px] w-[100px]" : "w-0"
            }`}
          ></div>
        </div>
      </div>
      <br />
      {/* Progress Bar 2 */}
      <div>
        <h3>Level of experience</h3>
        <br />
        <div className="md:w-[550px] w-[350px] max-w-xl bg-gray-300 rounded-full h-2">
          <div
            className={`bg-blue-500 h-2 rounded-full transition-all duration-1000 ease-in-out ${
              isVisible ? "md:w-[350px] w-[150px]" : "w-0"
            }`}
          ></div>
        </div>
      </div>
      <br />
      {/* Progress Bar 3 */}
      <div>
        <h3>Level of projects done</h3>
        <br />
        <div className="md:w-[550px] w-[350px] max-w-xl bg-gray-300 rounded-full h-2">
          <div
            className={`bg-blue-500 h-2 rounded-full transition-all duration-1000 ease-in-out ${
              isVisible ? " md:w-[450px] w-[200px]" : "w-0"
            }`}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default ProgressBars;
