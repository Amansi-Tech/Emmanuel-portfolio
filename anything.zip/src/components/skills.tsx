import React from 'react'

const Skills = () => {
  return (
    <div>
        
        <div className="text-center">
        <div className="text-center m-[2rem]">
          <h2 className="text-white text-[35px]">Skills</h2>
          <div className="flex items-center justify-center md:gap-[60px] gap-[30px] mt-[2rem]">
            <div
              data-aos="zoom-in-up"
              data-aos-delay="300"
              className="bg-transparent text-blue-500 p-[20px] rounded-[15px] w-[7rem] border-2 cursor-pointer border-blue-500 hover:text-white hover:bg-blue-500"
            >
              <h4>Html</h4>
            </div>
            {/* <div className="bg-transparent text-blue-500 p-[20px] rounded-[15px] w-[7rem] border-2 cursor-pointer border-blue-500 hover:text-white hover:bg-blue-500">
              <h4>Html</h4>
              
            </div> */}
            <div
              data-aos="zoom-in-up"
              data-aos-delay="300"
              className="bg-transparent text-blue-500 p-[20px] rounded-[15px] w-[7rem] border-2 cursor-pointer border-blue-500 hover:text-white hover:bg-blue-500"
            >
              <h4>Css</h4>
            </div>
            <div
              data-aos="zoom-in-up"
              data-aos-delay="301"
              className="bg-transparent text-blue-500 p-[20px] rounded-[15px] w-[7rem] border-2 cursor-pointer border-blue-500 hover:text-white hover:bg-blue-500"
            >
              <h4>Javascript</h4>
            </div>
          </div>
          <div className="flex items-center justify-center md:gap-[60px] gap-[30px] mt-[2rem]">
            <div
              data-aos="zoom-in-up"
              data-aos-delay="302"
              className="bg-transparent text-blue-500 p-[20px] rounded-[15px] w-[7rem] border-2 cursor-pointer border-blue-500 hover:text-white hover:bg-blue-500"
            >
              <h4>Typescript</h4>
            </div>
            <div
              data-aos="zoom-in-up"
              data-aos-delay="303"
              className="bg-transparent text-blue-500 p-[20px] rounded-[15px] w-[7rem] border-2 cursor-pointer border-blue-500 hover:text-white hover:bg-blue-500"
            >
              <h4>React</h4>
            </div>
            <div
              data-aos="zoom-in-up"
              data-aos-delay="304"
              className="bg-transparent text-blue-500 p-[20px] rounded-[15px] w-[7rem] border-2 cursor-pointer border-blue-500 hover:text-white hover:bg-blue-500"
            >
              <h4>Next.js</h4>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Skills