declare module "aos"

    